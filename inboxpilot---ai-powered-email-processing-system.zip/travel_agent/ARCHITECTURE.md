# Architecture — Intelligent Travel Planning AI Agent

## 1. Overview

```
                         ┌─────────────────────┐
   POST /chat  ────────▶ │      FastAPI         │
                         │   (app/main.py)       │
                         └──────────┬───────────┘
                                    │
                                    ▼
                         ┌─────────────────────┐
                         │     TravelAgent       │  (app/agent.py)
                         │  per user_id session  │
                         └──────────┬───────────┘
                     ┌──────────────┼───────────────────┐
                     ▼              ▼                   ▼
          ┌───────────────┐ ┌──────────────┐  ┌────────────────────┐
          │  1. PLAN       │ │ 2. RESEARCH   │  │ 3. EXECUTE          │
          │  (LLM call,    │ │ (multi-hop    │  │ (agentic tool-use   │
          │  JSON subtask  │ │  RAG via      │  │  loop, dynamic tool │
          │  list)         │ │  Wikipedia)   │  │  selection)         │
          └───────────────┘ └──────────────┘  └─────────┬───────────┘
                                                          │
                        ┌─────────────────────────────────┼─────────────────────┐
                        ▼                 ▼                ▼                    ▼
                 get_weather      get_attractions   search_flights/hotels  remember/recall
                 (Open-Meteo)     (Wikipedia)        (deterministic mock)   _preferences
                                                                             (FAISS, per-user)
```

## 2. Why this shape

The brief asks for four things: (a) dynamic tool use, (b) short + long-term
memory, (c) a planning mechanism with multi-hop RAG, (d) a conversational
REST interface. The design maps each requirement onto one module rather than
folding everything into a single monolithic prompt, so each piece is testable
in isolation (see `tests/`).

## 3. Planning

`TravelAgent._make_plan()` makes a single, cheap LLM call that turns the raw
user goal into an ordered JSON list of sub-tasks (e.g. *check weather →
shortlist attractions → find hotel within budget → compile itinerary*). The
plan is injected into the system prompt for the execution phase so the model
has an explicit checklist to work through, rather than re-deriving strategy
from scratch inside the tool-use loop. This is a lightweight, dependency-free
analogue of LangChain's Plan-and-Execute pattern.

## 4. Multi-hop RAG

`app/rag.py` performs two retrieval hops before execution starts:

1. **Hop 1** — `get_city_overview(city)` fetches a general Wikipedia summary
   of the destination (history, character, why it's notable).
2. **Hop 2** — `get_attractions(city)` searches for attraction-specific pages
   and retrieves a focused summary for each one.

Both hops are concatenated into a single grounding context block passed to
the model, so itinerary suggestions cite real landmarks/descriptions instead
of the model's own (possibly outdated or hallucinated) knowledge. The same
two functions are *also* exposed as tools in the execution loop, so the agent
can re-query for a different city mentioned mid-conversation without a full
restart.

## 5. Dynamic tool use

Six tools are exposed to the model via Anthropic's native tool-use API
(`app/agent.py::TOOL_SCHEMAS`): `get_weather`, `get_attractions`,
`search_flights`, `search_hotels`, `remember_preference`,
`recall_preferences`. The model — not a hand-coded if/else tree — decides
which of these to call, with what arguments, and in what order, based on the
plan and the conversation so far. The agent loop (`handle_message`) simply
executes whatever tool calls come back until the model produces a final
answer (`stop_reason != "tool_use"`), capped at `MAX_AGENT_STEPS` to bound
runaway loops.

## 6. Memory

| | Short-term | Long-term |
|---|---|---|
| **Module** | `memory/short_term.py` | `memory/long_term.py` |
| **Storage** | In-process bounded deque | FAISS `IndexFlatL2` + JSON sidecar, on disk |
| **Scope** | Current session only | Per `user_id`, across sessions/restarts |
| **Purpose** | Resolve pronouns/follow-ups ("make it cheaper") | Remember durable preferences (diet, budget tier, pets, pace) |
| **Embeddings** | n/a | Local `all-MiniLM-L6-v2` (no API key/cost) |

Long-term memory is itself exposed as two agent tools
(`remember_preference` / `recall_preferences`) rather than being force-fed
into every prompt — this lets the model decide *when* a fact is durable
enough to persist and *when* it's relevant enough to recall, which is more
robust than a fixed rule.

## 7. API surface

| Endpoint | Purpose |
|---|---|
| `POST /chat` | Send a message, get back the plan + itinerary reply |
| `GET /preferences/{user_id}` | Inspect what long-term memory has stored (debugging/transparency) |
| `GET /health` | Liveness probe for container platforms |

## 8. Deployment

Single-container deployment via the included `Dockerfile` (see README §Deployment).
`DATA_DIR` should be mounted to persistent storage in any long-lived
deployment so FAISS indices survive restarts; `ANTHROPIC_API_KEY` is the only
required secret.

## 9. Known limitations / next steps

- Flight/hotel search is a deterministic mock per the assessment's own
  allowance — swapping in a real provider only requires replacing the body
  of `tools/travel_booking.py` since the function signatures/tool schemas
  already model a realistic booking API.
- Long-term memory currently stores only positive preference statements; a
  production version would add expiry/versioning (e.g. "no longer travels
  with a dog") and de-duplication beyond exact string match.
- The planner and executor currently share one model; for cost optimization
  the planning call could route to a smaller/cheaper model since it only
  needs to emit a short JSON list.
