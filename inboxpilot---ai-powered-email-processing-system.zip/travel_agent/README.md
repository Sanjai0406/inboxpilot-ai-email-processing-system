# Intelligent Travel Planning AI Agent

A plan-and-execute AI agent that designs a personalized 2-day city trip using
dynamic tool use, short- and long-term memory, and multi-hop retrieval-augmented
generation (RAG). Built for the Hipster Pte. Ltd. AI/ML Engineer assessment
(Task 2).

## What it does

Send it a message like *"Plan a 2-day trip to Kyoto, I'm vegetarian and on a
mid-range budget"* and it will:

1. **Plan** — break the goal into ordered sub-tasks (check weather, shortlist
   attractions, find a hotel, compile itinerary).
2. **Research** — retrieve a grounded city overview + attraction details via
   Wikipedia (2-hop RAG), so the itinerary isn't hallucinated.
3. **Act** — dynamically decide which tools to call (weather, mock
   flights/hotels, attractions, long-term memory) and in what order.
4. **Remember** — persist durable preferences (diet, budget tier, pace, pets,
   etc.) to a per-user FAISS vector store so they're available in future
   sessions, and recall them proactively.
5. **Respond** — a day-by-day (Day 1 / Day 2) itinerary grounded in the above.

## Architecture

See [`ARCHITECTURE.md`](ARCHITECTURE.md) for the technical write-up (component
diagram, tool selection rationale, memory design).

```
app/
  main.py              FastAPI app (REST API)
  agent.py             Plan-and-execute orchestrator + dynamic tool-use loop
  llm.py               Anthropic Messages API wrapper
  rag.py               Multi-hop retrieval orchestration
  models.py            Pydantic request/response schemas
  tools/
    weather.py         Open-Meteo forecast (free, no key)
    attractions.py     Wikipedia city/attraction retrieval (RAG source)
    travel_booking.py  Mock flight/hotel search
  memory/
    short_term.py       Bounded conversation window (in-process)
    long_term.py        FAISS vector store, persisted per user to disk
tests/
  test_tools.py        Offline unit tests (no network / API key needed)
  test_live.py         Network + LLM integration tests (opt-in)
```

## Setup

**Requirements:** Python 3.10+, an [Anthropic API key](https://console.anthropic.com/).

```bash
cd travel_agent
python -m venv .venv && source .venv/bin/activate   # optional but recommended
pip install -r requirements.txt

cp .env.example .env
# edit .env and set ANTHROPIC_API_KEY=sk-ant-...

uvicorn app.main:app --reload --port 8000
```

The API is now live at `http://localhost:8000`. Interactive docs (Swagger UI)
are auto-generated at `http://localhost:8000/docs`.

### Try it

```bash
curl -X POST http://localhost:8000/chat \
  -H "Content-Type: application/json" \
  -d '{
        "user_id": "sanjai",
        "message": "Plan a 2-day trip to Kyoto. I am vegetarian and on a mid-range budget.",
        "city_hint": "Kyoto"
      }'
```

```bash
# Later session -- long-term memory persists across process restarts
curl -X POST http://localhost:8000/chat \
  -H "Content-Type: application/json" \
  -d '{"user_id": "sanjai", "message": "Now plan the same for Osaka instead."}'

curl http://localhost:8000/preferences/sanjai
```

`city_hint` is optional — if omitted, the agent still works, it just skips the
proactive RAG pre-fetch and relies on the `get_attractions`/`get_weather` tools
being called dynamically as the model decides it needs them.

## Running tests

```bash
# Offline (default): deterministic mock-booking + short-term memory tests
pytest tests/test_tools.py -v

# Live (network + real API key required): weather/Wikipedia/FAISS-embedding
# download + full agent round-trip
RUN_LIVE_TESTS=1 pytest tests/test_live.py -v
```

## Deployment

A `Dockerfile` is included, pre-baking the embedding model to avoid a
first-request download penalty.

```bash
docker build -t travel-agent .
docker run -p 8000:8000 --env-file .env -v $(pwd)/data:/srv/app/data travel-agent
```

This image runs unmodified on any container platform that accepts a Dockerfile
(Render, AWS App Runner/ECS, Google Cloud Run, Azure Container Apps, Fly.io).
Mount `/srv/app/data` to a persistent volume so long-term memory survives
container restarts/redeploys.

## Design notes / trade-offs

- **No LangChain dependency.** The plan-and-execute loop and tool-calling are
  implemented directly against the Anthropic Messages API's native tool-use
  support. This keeps the dependency surface small and every step of the
  agent loop auditable, while still satisfying the "planning mechanism to
  break goals into sub-tasks" and "decide dynamically" requirements.
- **Free, keyless data tools.** Weather (Open-Meteo) and attractions
  (Wikipedia) need no API keys, so the only secret required to run this
  end-to-end is the LLM key. Flight/hotel search is explicitly scoped by the
  assessment brief as mockable, so it's a deterministic seeded mock rather
  than a paid booking API integration.
- **Local embeddings.** Long-term memory uses a local sentence-transformers
  model (not the LLM provider's embedding endpoint), so memory storage/recall
  doesn't consume LLM API quota and keeps working even if the LLM key is
  swapped or temporarily invalid.
