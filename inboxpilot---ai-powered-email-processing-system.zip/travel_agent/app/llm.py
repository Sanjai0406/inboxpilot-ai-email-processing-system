"""
Thin wrapper around the Anthropic Messages API.

Kept as a single narrow module so the LLM provider can be swapped later
(e.g. for OpenAI) without touching agent.py -- callers only depend on
`LLMClient.chat()`.
"""
from __future__ import annotations

import os
from typing import Any, Dict, List, Optional

from anthropic import Anthropic

DEFAULT_MODEL = os.environ.get("AGENT_MODEL", "claude-sonnet-4-5")


class LLMClient:
    def __init__(self, api_key: Optional[str] = None, model: str = DEFAULT_MODEL):
        api_key = api_key or os.environ.get("ANTHROPIC_API_KEY")
        if not api_key:
            raise RuntimeError(
                "ANTHROPIC_API_KEY is not set. Add it to your environment or .env file."
            )
        self._client = Anthropic(api_key=api_key)
        self.model = model

    def chat(
        self,
        messages: List[Dict[str, Any]],
        system: str,
        tools: Optional[List[Dict[str, Any]]] = None,
        max_tokens: int = 1024,
    ):
        """Single call to the model; returns the raw Message object so the
        agent loop can inspect stop_reason / tool_use blocks."""
        kwargs: Dict[str, Any] = dict(
            model=self.model,
            max_tokens=max_tokens,
            system=system,
            messages=messages,
        )
        if tools:
            kwargs["tools"] = tools
        return self._client.messages.create(**kwargs)
