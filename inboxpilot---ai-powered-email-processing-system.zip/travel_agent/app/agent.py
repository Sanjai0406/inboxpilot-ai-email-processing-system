"""
TravelAgent: the orchestrator that ties together planning, tool use,
short-term memory, long-term memory, and multi-hop RAG.

Design (custom Plan-and-Execute loop, no heavyweight framework required):

  1. PLAN   -- one LLM call turns the user's goal into an ordered list of
               sub-tasks (e.g. "check weather", "find 2 attractions per day",
               "find budget-tier hotel", "compile day-by-day itinerary").
  2. RESEARCH -- multi-hop RAG pulls a grounded city/attraction context block
               so the plan/execution isn't relying on the model's parametric
               memory for facts.
  3. EXECUTE -- one agentic tool-use loop (weather / flights / hotels /
               attractions / long-term-memory tools) runs guided by the plan,
               deciding *dynamically* which tools it needs and in what order,
               until it produces a final answer.
"""
from __future__ import annotations

import json
from typing import Any, Dict, List

from .llm import LLMClient
from .memory import ShortTermMemory, LongTermMemory
from .rag import multi_hop_city_research, format_context_block
from .tools import get_weather, get_city_overview, get_attractions, search_flights, search_hotels

MAX_AGENT_STEPS = 6

# ---- Tool schemas exposed to the LLM (Anthropic tool-use format) ----------
TOOL_SCHEMAS: List[Dict[str, Any]] = [
    {
        "name": "get_weather",
        "description": "Get a 3-day weather forecast for a city.",
        "input_schema": {
            "type": "object",
            "properties": {"city": {"type": "string"}},
            "required": ["city"],
        },
    },
    {
        "name": "get_attractions",
        "description": "Get notable attractions/landmarks for a city with descriptions.",
        "input_schema": {
            "type": "object",
            "properties": {
                "city": {"type": "string"},
                "max_results": {"type": "integer", "default": 5},
            },
            "required": ["city"],
        },
    },
    {
        "name": "search_flights",
        "description": "Search mock flight offers between two cities on a date.",
        "input_schema": {
            "type": "object",
            "properties": {
                "origin": {"type": "string"},
                "destination": {"type": "string"},
                "date": {"type": "string", "description": "YYYY-MM-DD"},
            },
            "required": ["origin", "destination", "date"],
        },
    },
    {
        "name": "search_hotels",
        "description": "Search mock hotel offers in a city for given dates and budget tier.",
        "input_schema": {
            "type": "object",
            "properties": {
                "city": {"type": "string"},
                "check_in": {"type": "string"},
                "check_out": {"type": "string"},
                "budget_tier": {
                    "type": "string",
                    "enum": ["budget", "mid-range", "luxury"],
                },
            },
            "required": ["city", "check_in", "check_out"],
        },
    },
    {
        "name": "remember_preference",
        "description": (
            "Persist a durable user travel preference (diet, budget style, "
            "pace, accessibility needs, pets, seat preference, etc.) to "
            "long-term memory so it is available in future sessions."
        ),
        "input_schema": {
            "type": "object",
            "properties": {"statement": {"type": "string"}},
            "required": ["statement"],
        },
    },
    {
        "name": "recall_preferences",
        "description": "Retrieve previously remembered user preferences relevant to a query.",
        "input_schema": {
            "type": "object",
            "properties": {"query": {"type": "string"}},
            "required": ["query"],
        },
    },
]

SYSTEM_PROMPT = """You are an expert travel-planning agent. You help a user design a \
personalized 2-day trip to a city.

You have tools for weather, attractions (grounded via retrieval -- prefer these \
facts over your own assumptions), mock flight/hotel search, and long-term memory \
of user preferences. Decide dynamically which tools you actually need; do not \
call a tool if the information is already available in context.

When you learn a durable preference (diet, budget tier, travel pace, traveling \
with pets/kids, mobility needs, seat/room preferences), call remember_preference \
so it persists across sessions. At the start of planning, consider calling \
recall_preferences to check what you already know about this user.

If the user's request is ambiguous (no city, no dates), ask a concise \
clarifying question instead of guessing.

Always finish with a clear, day-by-day (Day 1 / Day 2) itinerary including \
morning/afternoon/evening blocks, referencing weather and budget where relevant."""


class TravelAgent:
    def __init__(self, user_id: str, llm: LLMClient = None, data_dir: str = "data"):
        self.user_id = user_id
        self.llm = llm or LLMClient()
        self.short_term = ShortTermMemory()
        self.long_term = LongTermMemory(user_id=user_id, data_dir=data_dir)
        self._tool_impl = {
            "get_weather": lambda **kw: get_weather(**kw),
            "get_attractions": lambda **kw: get_attractions(**kw),
            "search_flights": lambda **kw: search_flights(**kw),
            "search_hotels": lambda **kw: search_hotels(**kw),
            "remember_preference": self._tool_remember,
            "recall_preferences": self._tool_recall,
        }

    # -- memory tool adapters --------------------------------------------
    def _tool_remember(self, statement: str) -> Dict[str, Any]:
        self.long_term.remember(statement)
        return {"status": "stored", "statement": statement}

    def _tool_recall(self, query: str) -> Dict[str, Any]:
        return {"preferences": self.long_term.recall(query)}

    # -- planning ----------------------------------------------------------
    def _make_plan(self, goal: str) -> List[str]:
        planning_messages = [
            {
                "role": "user",
                "content": (
                    "Break the following trip-planning goal into 3-6 short, ordered "
                    "sub-tasks (e.g. 'check weather', 'shortlist attractions', "
                    "'find hotel within budget', 'compose day-by-day itinerary'). "
                    'Respond ONLY with a JSON array of strings, no prose.\n\n'
                    f"Goal: {goal}"
                ),
            }
        ]
        response = self.llm.chat(
            messages=planning_messages,
            system="You are a meticulous trip-planning assistant that outputs strict JSON.",
            max_tokens=300,
        )
        text = "".join(block.text for block in response.content if block.type == "text")
        try:
            plan = json.loads(text)
            if isinstance(plan, list):
                return [str(step) for step in plan]
        except json.JSONDecodeError:
            pass
        # Fallback: treat each non-empty line as a step.
        return [line.strip("-• ") for line in text.splitlines() if line.strip()]

    # -- main entry point ---------------------------------------------------
    def handle_message(self, user_message: str, city_hint: str = None) -> Dict[str, Any]:
        self.short_term.add("user", user_message)

        plan = self._make_plan(user_message)

        research_context = ""
        if city_hint:
            research = multi_hop_city_research(city_hint)
            research_context = format_context_block(research)

        system = SYSTEM_PROMPT + "\n\nCurrent plan:\n" + "\n".join(
            f"{i + 1}. {step}" for i, step in enumerate(plan)
        )
        if research_context:
            system += "\n\nGrounded retrieval context (prefer this over assumptions):\n" + research_context

        messages: List[Dict[str, Any]] = list(self.short_term.as_messages())

        final_text = ""
        for _ in range(MAX_AGENT_STEPS):
            response = self.llm.chat(messages=messages, system=system, tools=TOOL_SCHEMAS)

            if response.stop_reason != "tool_use":
                final_text = "".join(b.text for b in response.content if b.type == "text")
                break

            # Append the assistant turn (including tool_use blocks) then run tools.
            messages.append({"role": "assistant", "content": response.content})
            tool_results = []
            for block in response.content:
                if block.type != "tool_use":
                    continue
                fn = self._tool_impl.get(block.name)
                try:
                    result = fn(**block.input) if fn else {"error": f"unknown tool {block.name}"}
                except Exception as exc:  # tool errors shouldn't crash the agent loop
                    result = {"error": str(exc)}
                tool_results.append(
                    {
                        "type": "tool_result",
                        "tool_use_id": block.id,
                        "content": json.dumps(result, default=str),
                    }
                )
            messages.append({"role": "user", "content": tool_results})
        else:
            final_text = "I wasn't able to finish planning within the step budget -- please narrow the request."

        self.short_term.add("assistant", final_text)
        return {"plan": plan, "reply": final_text}
