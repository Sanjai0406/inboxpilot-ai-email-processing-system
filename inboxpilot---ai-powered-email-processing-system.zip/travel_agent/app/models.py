from typing import List, Optional

from pydantic import BaseModel, Field


class ChatRequest(BaseModel):
    user_id: str = Field(..., description="Stable identifier for the user; keys long-term memory.")
    message: str = Field(..., description="The user's message / trip request.")
    city_hint: Optional[str] = Field(
        None, description="Optional explicit city name to force multi-hop RAG retrieval for."
    )


class ChatResponse(BaseModel):
    plan: List[str]
    reply: str


class PreferencesResponse(BaseModel):
    user_id: str
    preferences: List[str]
