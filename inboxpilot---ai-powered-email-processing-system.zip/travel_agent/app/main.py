"""
FastAPI entrypoint.

Run locally:
    uvicorn app.main:app --reload --port 8000

Endpoints:
    POST /chat                 -> converse with the agent, get an itinerary/plan
    GET  /preferences/{user_id} -> inspect what long-term memory has stored
    GET  /health                -> liveness check (for container/cloud probes)
"""
from __future__ import annotations

import os
from threading import Lock
from typing import Dict

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException

from .agent import TravelAgent
from .memory import LongTermMemory
from .models import ChatRequest, ChatResponse, PreferencesResponse

load_dotenv()

app = FastAPI(
    title="Intelligent Travel Planning Agent",
    description="Plan-and-execute AI agent for personalized 2-day city trips.",
    version="1.0.0",
)

_sessions: Dict[str, TravelAgent] = {}
_sessions_lock = Lock()


def _get_agent(user_id: str) -> TravelAgent:
    with _sessions_lock:
        if user_id not in _sessions:
            _sessions[user_id] = TravelAgent(user_id=user_id, data_dir=os.environ.get("DATA_DIR", "data"))
        return _sessions[user_id]


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/chat", response_model=ChatResponse)
def chat(req: ChatRequest):
    try:
        agent = _get_agent(req.user_id)
        result = agent.handle_message(req.message, city_hint=req.city_hint)
    except RuntimeError as exc:
        # e.g. missing ANTHROPIC_API_KEY -- surfaced as a clean 500, not a crash
        raise HTTPException(status_code=500, detail=str(exc))
    return ChatResponse(**result)


@app.get("/preferences/{user_id}", response_model=PreferencesResponse)
def preferences(user_id: str):
    # Reads long-term memory directly -- no LLM client needed just to inspect
    # what's been remembered, so this works even without an API key configured.
    memory = LongTermMemory(user_id=user_id, data_dir=os.environ.get("DATA_DIR", "data"))
    return PreferencesResponse(user_id=user_id, preferences=memory.all_preferences())
