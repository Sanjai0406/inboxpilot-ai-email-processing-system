"""
Long-term memory: a per-user FAISS vector store of remembered preference
statements ("I prefer window seats", "I'm vegetarian", "I travel with a
dog"), persisted to disk so it survives across sessions/process restarts.

Embeddings use `sentence-transformers/all-MiniLM-L6-v2` (local, CPU,
no API key) so long-term memory works even without an LLM provider key
configured -- only generation calls the paid/keyed LLM.
"""
from __future__ import annotations

import json
import os
import threading
from typing import List, Tuple

import faiss
import numpy as np
from sentence_transformers import SentenceTransformer

_EMBED_DIM = 384  # all-MiniLM-L6-v2 output size
_MODEL_NAME = "sentence-transformers/all-MiniLM-L6-v2"

_model_lock = threading.Lock()
_model = None


def _get_model() -> SentenceTransformer:
    global _model
    with _model_lock:
        if _model is None:
            _model = SentenceTransformer(_MODEL_NAME)
        return _model


class LongTermMemory:
    """
    One instance manages one user's persisted preference store:
      data/{user_id}.index  -> FAISS index (vectors)
      data/{user_id}.json   -> parallel list of the original text strings
    """

    def __init__(self, user_id: str, data_dir: str = "data"):
        self.user_id = user_id
        self.data_dir = data_dir
        os.makedirs(data_dir, exist_ok=True)
        self._index_path = os.path.join(data_dir, f"{user_id}.index")
        self._texts_path = os.path.join(data_dir, f"{user_id}.json")
        self._texts: List[str] = []
        self._index = self._load_or_create_index()

    def _load_or_create_index(self) -> "faiss.Index":
        if os.path.exists(self._index_path) and os.path.exists(self._texts_path):
            index = faiss.read_index(self._index_path)
            with open(self._texts_path, "r") as f:
                self._texts = json.load(f)
            return index
        return faiss.IndexFlatL2(_EMBED_DIM)

    def _save(self) -> None:
        faiss.write_index(self._index, self._index_path)
        with open(self._texts_path, "w") as f:
            json.dump(self._texts, f)

    def remember(self, statement: str) -> None:
        """Embed and persist a new preference statement."""
        if statement in self._texts:
            return  # avoid duplicate entries
        vec = _get_model().encode([statement], normalize_embeddings=True)
        self._index.add(np.array(vec, dtype="float32"))
        self._texts.append(statement)
        self._save()

    def recall(self, query: str, k: int = 3) -> List[str]:
        """Return the k most relevant remembered preferences for `query`."""
        if self._index.ntotal == 0:
            return []
        vec = _get_model().encode([query], normalize_embeddings=True)
        k = min(k, self._index.ntotal)
        distances, indices = self._index.search(np.array(vec, dtype="float32"), k)
        return [self._texts[i] for i in indices[0] if i != -1]

    def all_preferences(self) -> List[str]:
        return list(self._texts)
