"""
Short-term memory = the rolling conversation window for a single session.

Kept intentionally simple (a bounded deque) since its only job is to give
the planner recent turns for context resolution (pronouns, follow-up
questions like "make it cheaper" / "what about day 2"). Cross-session
knowledge lives in LongTermMemory instead.
"""
from __future__ import annotations

from collections import deque
from typing import Deque, Dict, List


class ShortTermMemory:
    def __init__(self, max_turns: int = 12):
        self._turns: Deque[Dict[str, str]] = deque(maxlen=max_turns)

    def add(self, role: str, content: str) -> None:
        self._turns.append({"role": role, "content": content})

    def as_messages(self) -> List[Dict[str, str]]:
        return list(self._turns)

    def clear(self) -> None:
        self._turns.clear()
