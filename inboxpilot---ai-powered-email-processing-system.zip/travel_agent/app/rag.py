"""
Multi-hop retrieval-augmented generation.

Hop 1 -- retrieve a general city summary (Wikipedia).
Hop 2 -- using entities/attractions surfaced in hop 1, retrieve a focused
         summary for each individual attraction.

The result is a compact context block the agent can ground its itinerary
suggestions in, rather than hallucinating landmark names/descriptions.
"""
from __future__ import annotations

from typing import Any, Dict

from .tools.attractions import get_city_overview, get_attractions


def multi_hop_city_research(city: str, max_attractions: int = 5) -> Dict[str, Any]:
    hop1 = get_city_overview(city)
    hop2 = get_attractions(city, max_results=max_attractions)
    return {"city_overview": hop1, "attractions": hop2}


def format_context_block(research: Dict[str, Any]) -> str:
    """Render retrieved hops as plain text to inject into the LLM prompt."""
    lines = []
    overview = research.get("city_overview", {})
    if overview.get("extract"):
        lines.append(f"CITY OVERVIEW ({overview.get('title', '')}): {overview['extract']}")

    for attraction in research.get("attractions", []):
        if attraction.get("extract"):
            lines.append(f"ATTRACTION -- {attraction['title']}: {attraction['extract']}")

    return "\n\n".join(lines) if lines else "No external retrieval results found."
