"""
Weather tool.

Uses the free, keyless Open-Meteo API:
  1. Geocoding:  https://geocoding-api.open-meteo.com/v1/search?name={city}
  2. Forecast:   https://api.open-meteo.com/v1/forecast?latitude=..&longitude=..

No API key is required, which keeps the assessment self-contained and
reproducible for a reviewer without needing secrets.
"""
from __future__ import annotations

import requests
from typing import Any, Dict

GEOCODE_URL = "https://geocoding-api.open-meteo.com/v1/search"
FORECAST_URL = "https://api.open-meteo.com/v1/forecast"

TOOL_SPEC = {
    "name": "get_weather",
    "description": (
        "Get a short-range (up to 3 day) weather forecast for a city. "
        "Use this whenever the trip plan depends on outdoor activities "
        "or packing advice."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "city": {"type": "string", "description": "City name, e.g. 'Tokyo'"},
        },
        "required": ["city"],
    },
}


def _geocode(city: str) -> Dict[str, Any]:
    resp = requests.get(GEOCODE_URL, params={"name": city, "count": 1}, timeout=10)
    resp.raise_for_status()
    results = resp.json().get("results")
    if not results:
        raise ValueError(f"Could not geocode city: {city}")
    top = results[0]
    return {
        "latitude": top["latitude"],
        "longitude": top["longitude"],
        "resolved_name": top.get("name", city),
        "country": top.get("country", ""),
    }


def get_weather(city: str) -> Dict[str, Any]:
    """Return a compact 3-day daily forecast for `city`."""
    loc = _geocode(city)
    params = {
        "latitude": loc["latitude"],
        "longitude": loc["longitude"],
        "daily": "temperature_2m_max,temperature_2m_min,precipitation_probability_max,weathercode",
        "forecast_days": 3,
        "timezone": "auto",
    }
    resp = requests.get(FORECAST_URL, params=params, timeout=10)
    resp.raise_for_status()
    daily = resp.json().get("daily", {})

    days = []
    for i, date in enumerate(daily.get("time", [])):
        days.append(
            {
                "date": date,
                "temp_max_c": daily["temperature_2m_max"][i],
                "temp_min_c": daily["temperature_2m_min"][i],
                "precipitation_chance_pct": daily["precipitation_probability_max"][i],
            }
        )

    return {
        "city": loc["resolved_name"],
        "country": loc["country"],
        "forecast": days,
    }
