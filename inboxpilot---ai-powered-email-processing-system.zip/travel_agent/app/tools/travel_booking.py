"""
Mock flight/hotel API.

A real booking API needs commercial credentials, so per the assessment brief
("mock flight/hotel API" is an explicitly listed option) this module
deterministically synthesizes plausible offers from the input parameters.
The interface (function signature + returned schema) is written so that
swapping in a real provider (e.g. Amadeus, Skyscanner) later only requires
replacing the function body.
"""
from __future__ import annotations

import hashlib
from typing import Any, Dict, List

TOOL_SPEC = {
    "name": "search_flights",
    "description": "Search mock flight offers to a destination city for given dates.",
    "parameters": {
        "type": "object",
        "properties": {
            "origin": {"type": "string"},
            "destination": {"type": "string"},
            "date": {"type": "string", "description": "YYYY-MM-DD"},
        },
        "required": ["origin", "destination", "date"],
    },
}

HOTELS_TOOL_SPEC = {
    "name": "search_hotels",
    "description": "Search mock hotel offers in a city for given check-in/out dates and budget tier.",
    "parameters": {
        "type": "object",
        "properties": {
            "city": {"type": "string"},
            "check_in": {"type": "string"},
            "check_out": {"type": "string"},
            "budget_tier": {
                "type": "string",
                "enum": ["budget", "mid-range", "luxury"],
                "default": "mid-range",
            },
        },
        "required": ["city", "check_in", "check_out"],
    },
}

_AIRLINES = ["SkyLink Air", "Pacific Wings", "AeroConnect", "TransCity Airlines"]
_HOTEL_CHAINS = {
    "budget": ["StaySimple Inn", "Bunkhouse Hostel", "CityStop Lodge"],
    "mid-range": ["Harbor View Hotel", "Central Plaza Hotel", "Garden Suites"],
    "luxury": ["The Regency Grand", "Aurora Palace Hotel", "Skyline Signature Resort"],
}


def _seeded_value(seed: str, low: int, high: int) -> int:
    """Deterministic pseudo-random int in [low, high] derived from a seed string."""
    h = int(hashlib.sha256(seed.encode()).hexdigest(), 16)
    return low + (h % (high - low + 1))


def search_flights(origin: str, destination: str, date: str) -> List[Dict[str, Any]]:
    offers = []
    for i, airline in enumerate(_AIRLINES[:3]):
        seed = f"{origin}-{destination}-{date}-{airline}"
        price = _seeded_value(seed, 180, 950)
        duration_min = _seeded_value(seed + "dur", 90, 780)
        offers.append(
            {
                "airline": airline,
                "origin": origin,
                "destination": destination,
                "date": date,
                "price_usd": price,
                "duration_minutes": duration_min,
                "stops": _seeded_value(seed + "stops", 0, 2),
            }
        )
    return sorted(offers, key=lambda o: o["price_usd"])


def search_hotels(
    city: str, check_in: str, check_out: str, budget_tier: str = "mid-range"
) -> List[Dict[str, Any]]:
    tier = budget_tier if budget_tier in _HOTEL_CHAINS else "mid-range"
    base_price = {"budget": 40, "mid-range": 120, "luxury": 350}[tier]
    offers = []
    for name in _HOTEL_CHAINS[tier]:
        seed = f"{city}-{check_in}-{check_out}-{name}"
        price = base_price + _seeded_value(seed, -20, 80)
        rating = round(3.5 + _seeded_value(seed + "r", 0, 15) / 10, 1)
        offers.append(
            {
                "name": name,
                "city": city,
                "check_in": check_in,
                "check_out": check_out,
                "budget_tier": tier,
                "price_per_night_usd": max(price, 15),
                "rating": min(rating, 5.0),
            }
        )
    return sorted(offers, key=lambda o: -o["rating"])
