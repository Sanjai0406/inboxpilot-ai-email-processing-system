"""
Attraction / city-knowledge tool.

Uses the free, keyless Wikipedia REST API as an external knowledge source.
This doubles as the retrieval leg of the multi-hop RAG pipeline (see
app/rag.py): the agent first retrieves a city summary, then does a
second-hop retrieval per candidate attraction mentioned in that summary.
"""
from __future__ import annotations

import re
import requests
from typing import Any, Dict, List

WIKI_SUMMARY_URL = "https://en.wikipedia.org/api/rest_v1/page/summary/{title}"
WIKI_SEARCH_URL = "https://en.wikipedia.org/w/api.php"

TOOL_SPEC = {
    "name": "get_city_overview",
    "description": "Retrieve a general knowledge summary of a city (history, character, highlights).",
    "parameters": {
        "type": "object",
        "properties": {"city": {"type": "string"}},
        "required": ["city"],
    },
}

ATTRACTIONS_TOOL_SPEC = {
    "name": "get_attractions",
    "description": (
        "Retrieve a short list of notable attractions/landmarks for a city, "
        "each with a one-paragraph description (second RAG hop)."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "city": {"type": "string"},
            "max_results": {"type": "integer", "default": 5},
        },
        "required": ["city"],
    },
}


def _wiki_search(query: str, limit: int = 8) -> List[str]:
    params = {
        "action": "query",
        "list": "search",
        "srsearch": query,
        "format": "json",
        "srlimit": limit,
    }
    resp = requests.get(WIKI_SEARCH_URL, params=params, timeout=10)
    resp.raise_for_status()
    hits = resp.json().get("query", {}).get("search", [])
    return [h["title"] for h in hits]


def _wiki_summary(title: str) -> Dict[str, Any]:
    resp = requests.get(WIKI_SUMMARY_URL.format(title=title.replace(" ", "_")), timeout=10)
    if resp.status_code != 200:
        return {}
    data = resp.json()
    return {
        "title": data.get("title", title),
        "extract": data.get("extract", ""),
        "url": data.get("content_urls", {}).get("desktop", {}).get("page", ""),
    }


def get_city_overview(city: str) -> Dict[str, Any]:
    """Hop 1: general knowledge summary of the destination city."""
    summary = _wiki_summary(city)
    if not summary:
        titles = _wiki_search(city, limit=1)
        summary = _wiki_summary(titles[0]) if titles else {"title": city, "extract": "", "url": ""}
    return summary


def get_attractions(city: str, max_results: int = 5) -> List[Dict[str, Any]]:
    """Hop 2: pull individual attraction pages related to the city."""
    titles = _wiki_search(f"tourist attractions in {city}", limit=max_results * 2)
    results = []
    seen = set()
    for title in titles:
        if title.lower() == city.lower():
            continue
        summary = _wiki_summary(title)
        extract = summary.get("extract", "")
        if not extract or summary["title"] in seen:
            continue
        seen.add(summary["title"])
        results.append(summary)
        if len(results) >= max_results:
            break
    return results
