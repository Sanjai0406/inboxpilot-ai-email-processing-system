"""
Live tests that need real outbound internet (Wikipedia, Open-Meteo,
huggingface.co model download) and/or ANTHROPIC_API_KEY.

These are skipped by default because CI/sandbox environments often
restrict egress. Run explicitly with:

    RUN_LIVE_TESTS=1 pytest tests/test_live.py -v
"""
import os
import shutil
import sys

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

pytestmark = pytest.mark.skipif(
    os.environ.get("RUN_LIVE_TESTS") != "1",
    reason="set RUN_LIVE_TESTS=1 to run tests that hit the network / a real API key",
)


def test_weather_tool_live():
    from app.tools.weather import get_weather

    result = get_weather("Paris")
    assert result["city"]
    assert len(result["forecast"]) == 3


def test_attractions_tool_live():
    from app.tools.attractions import get_city_overview, get_attractions

    overview = get_city_overview("Kyoto")
    assert overview.get("extract")
    attractions = get_attractions("Kyoto", max_results=3)
    assert len(attractions) > 0


def test_long_term_memory_roundtrip_live(tmp_path):
    from app.memory.long_term import LongTermMemory

    data_dir = str(tmp_path / "mem_data")
    mem = LongTermMemory(user_id="test_user", data_dir=data_dir)
    mem.remember("Prefers vegetarian food")
    mem.remember("Travels with a small dog")
    mem.remember("Budget-conscious, prefers 3-star hotels")

    results = mem.recall("What food does the user eat?", k=1)
    assert results
    assert "vegetarian" in results[0].lower()

    mem2 = LongTermMemory(user_id="test_user", data_dir=data_dir)
    assert len(mem2.all_preferences()) == 3
    shutil.rmtree(data_dir, ignore_errors=True)


def test_agent_end_to_end_live():
    from app.agent import TravelAgent

    agent = TravelAgent(user_id="live_test_user", data_dir="data_live_test")
    result = agent.handle_message(
        "Plan a 2-day trip to Kyoto for a vegetarian traveler on a mid-range budget.",
        city_hint="Kyoto",
    )
    assert result["plan"]
    assert "Day 1" in result["reply"] or "day 1" in result["reply"].lower()
    shutil.rmtree("data_live_test", ignore_errors=True)
