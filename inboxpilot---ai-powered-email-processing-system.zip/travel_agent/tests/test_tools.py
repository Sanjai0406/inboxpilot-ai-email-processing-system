"""
Tests that run offline (no network, no API key):
 - mock flight/hotel search determinism & schema
 - long-term FAISS memory store/recall round-trip
 - short-term memory windowing

Network-dependent tools (weather, attractions/Wikipedia) and the LLM agent
loop are exercised in tests/test_live.py, which is skipped unless
RUN_LIVE_TESTS=1 is set (since this sandbox has no outbound internet
access to those domains and no ANTHROPIC_API_KEY).
"""
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from app.tools.travel_booking import search_flights, search_hotels
from app.memory.short_term import ShortTermMemory


def test_search_flights_schema_and_sorting():
    offers = search_flights("SIN", "NRT", "2026-08-01")
    assert len(offers) == 3
    assert all({"airline", "price_usd", "duration_minutes", "stops"} <= o.keys() for o in offers)
    prices = [o["price_usd"] for o in offers]
    assert prices == sorted(prices)


def test_search_flights_deterministic():
    a = search_flights("SIN", "NRT", "2026-08-01")
    b = search_flights("SIN", "NRT", "2026-08-01")
    assert a == b  # same seed -> same mock offers


def test_search_hotels_budget_tiers():
    for tier in ["budget", "mid-range", "luxury"]:
        offers = search_hotels("Tokyo", "2026-08-01", "2026-08-03", budget_tier=tier)
        assert len(offers) == 3
        assert all(o["budget_tier"] == tier for o in offers)
        ratings = [o["rating"] for o in offers]
        assert ratings == sorted(ratings, reverse=True)


def test_short_term_memory_window():
    mem = ShortTermMemory(max_turns=3)
    for i in range(5):
        mem.add("user", f"msg {i}")
    turns = mem.as_messages()
    assert len(turns) == 3
    assert turns[0]["content"] == "msg 2"  # oldest two dropped
    assert turns[-1]["content"] == "msg 4"


if __name__ == "__main__":
    import pytest

    raise SystemExit(pytest.main([__file__, "-v"]))
