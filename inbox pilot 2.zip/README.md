# InboxPilot — AI-Powered Email Processing System

> **Junior Engineer Assessment Submission**  
> *A production-minded, human-in-the-loop email automation pipeline utilizing Gemini AI understanding paired with deterministic safety guardrails, feedback memory, and audit logging.*

---

## 1. Problem Statement

Support and operations teams receive hundreds of incoming emails daily spanning diverse intents: urgent outages, billing disputes, enterprise sales inquiries, account cancellations, and ambiguous requests.

Naive LLM implementations suffer from two critical hazards:
1. **Hallucination & Unpredictability:** An LLM may attempt to execute destructive external actions (e.g. issuing refunds or deleting user records) without authorization.
2. **Brittle Automations:** LLMs can misclassify ambiguous or missing-information queries, leading to incorrect automated routing.

---

## 2. Solution Overview

**InboxPilot** solves this by establishing a strict architectural separation:
- **LLM Layer (Gemini):** Responsible **solely** for entity extraction, intent understanding, and factual confidence calculation. It **never** executes actions.
- **Deterministic Decision Engine & Safety Guardrails:** Code-governed business rules evaluate the AI payload against strict security boundaries.
- **Human Review & Feedback Memory:** Any high-impact, low-confidence, or financial request is escalated to human operators. Operator corrections are stored in a lightweight **Feedback Memory** to guide future similar emails without claiming dangerous black-box model retraining.

---

## 3. Key Features

- **Multi-Stage Email Processing Pipeline:** Validates and normalizes inputs, extracts structured JSON schemas via Gemini, validates outputs, and routes through business rules.
- **Deterministic Safety Guardrails:**
  - Automated blocks on financial transactions, refunds, cancellations, and data erasures.
  - Mandatory human review for confidence $< 0.70$ or unknown intents.
  - Detection of missing parameters (e.g., missing invoice IDs) triggering clarification requests.
- **Human Approval & Review Queue:** Side-by-side comparison of original email, AI analysis, triggered safety flags, and simulated action approvals.
- **Human Feedback Loop & Feedback Memory:** Human corrections create search-indexed memory records that provide feedback-informed suggestions for future similar emails.
- **Resilient Retry Handling:** Up to 3 retries with exponential backoff on timeouts or malformed payloads, with graceful fallback to Human Review upon exhaustion.
- **Comprehensive Audit Logger:** Every pipeline stage, attempt, safety check, and reviewer decision is recorded in an immutable, sanitized audit log.
- **Automated 12-Scenario Test Suite:** 1-click execution verifying classification, safety, retries, and feedback memory.
- **System Health Monitor:** Real-time visibility into LLM gateway status, processing latencies, error rates, and configurable limits.

---

## 4. End-to-End Processing Workflow

```
Incoming Email (Sender, Subject, Body)
       │
       ▼
Email Processor (Length validation, sanitization)
       │
       ▼
LLM AI Analysis (Gemini 3.8 Flash structured extraction)
       │
       ▼
Structured Output Validation (Schema verification, confidence checks)
       │
       ├─── [If Invalid / Error] ──► Retry Handler (≤ 3 Retries) ──► [Exhausted] ──► Human Review
       │
       ▼
Deterministic Decision Engine (Pure business rules)
       │
       ▼
Safety Guardrails
       │
       ├─── [High Risk / Financial / Refund / Deletion / Low Confidence] ──► Human Review Queue
       │                                                                            │
       │                                                                 (Approve / Reject / Correct)
       │                                                                            │
       ▼                                                                            ▼
Recommended Safe Action                                                     Feedback Memory
(Route / Ask Info / Provide Info)                                                   │
       │                                                                            ▼
       └──────────────────────────────────┬─────────────────────────────────────────┘
                                          ▼
                                    Final Outcome
                                          │
                                          ▼
                                     Audit Logger
```

---

## 5. Security & Safety Principles

1. **API Keys Server-Side:** All Gemini interactions happen exclusively in Node/Express (`server.ts`). Secrets are never exposed to browser bundles.
2. **Simulated External Actions:** The system explicitly flags all external operations (refunds, cancellations, deletions) as simulated to prevent unintended side effects.
3. **Urgency Does Not Bypass Safety:** An email with "Critical" urgency regarding a refund will **always** trigger human review.
4. **Sanitized Telemetry:** Secrets, passwords, and tokens are stripped before writing to audit events.

---

## 6. Environment Variables

| Variable | Description | Default |
| :--- | :--- | :--- |
| `GEMINI_API_KEY` | Google Gemini API Key | Required for live LLM calls (deterministic fallback provided if missing) |
| `PORT` | Container Port | `3000` |
| `NODE_ENV` | Environment mode (`development` or `production`) | `development` |

---

## 7. Setup & Running the Application

### Install Dependencies
```bash
npm install
```

### Start Development Server
```bash
npm run dev
```
The app will be available on `http://localhost:3000`.

### Production Build
```bash
npm run build
npm start
```

---

## 8. AI-Assisted Development Disclosure

This application was engineered with AI assistance for code generation, interface styling, and synthetic dataset creation in accordance with Google AI Studio build guidelines. All business logic, deterministic guardrails, and architectural boundaries were designed to satisfy production-grade assessment criteria.
