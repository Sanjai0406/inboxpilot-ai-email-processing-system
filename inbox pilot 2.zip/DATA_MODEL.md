# InboxPilot Data Models & Schemas

## 1. Entity Relationship Overview

```
Email (1)
  │
  ├──────────────► ProcessingRun (1..N)
  │
  ├──────────────► AIAnalysis (1)
  │                    │
  │                    ▼
  │                 Decision (1)
  │                    │
  │                    ▼
  │               AuditEvent (1..N)
  │
  └──────────────► HumanFeedback (0..1)
                       │
                       ▼
                 FeedbackMemory (1)
                       │
                       ▼
              Future Email Suggestion
```

---

## 2. Model Definitions

### `Email`
Primary entity representing an incoming message.
```typescript
interface Email {
  id: string;              // e.g. "em-101"
  sender: string;          // e.g. "sarah.connor@acme-corp.com"
  subject: string;         // e.g. "Invoice #INV-2026-8849 Payment Verification"
  body: string;            // Message text
  receivedAt: string;      // ISO 8601 timestamp
  status: 'RECEIVED' | 'PROCESSING' | 'COMPLETED' | 'HUMAN_REVIEW' | 'FAILED';
  categoryTag?: string;    // Synthetic classification tag
  simulatedScenario?: string;
}
```

### `ProcessingRun`
Execution telemetry for a single email processing attempt.
```typescript
interface ProcessingRun {
  id: string;
  emailId: string;
  status: 'PENDING' | 'RUNNING' | 'SUCCESS' | 'FAILED' | 'ESCALATED';
  startedAt: string;
  completedAt?: string;
  retryCount: number;
  error?: string;
  processingTimeMs: number;
  attempts: Array<{
    attemptNumber: number;
    timestamp: string;
    stage: string;
    success: boolean;
    error?: string;
    durationMs: number;
  }>;
}
```

### `AIAnalysis`
Grounded structured understanding produced by Gemini.
```typescript
interface AIAnalysis {
  id: string;
  emailId: string;
  intent: 'Billing' | 'Technical Support' | 'Sales' | 'Account Support' | 'General Support' | 'Complaint' | 'Cancellation' | 'Refund' | 'Other' | 'Unknown';
  importantDetails: string[];
  urgency: 'Low' | 'Medium' | 'High' | 'Critical' | 'Unknown';
  missingInformation: string[];
  confidence: number;       // 0.00 to 1.00
  reasoningSummary: string;
  rawJson?: string;
  validationPassed: boolean;
  validationErrors?: string[];
  createdAt: string;
}
```

### `Decision`
Deterministic business decision output with risk assessment.
```typescript
interface Decision {
  id: string;
  emailId: string;
  recommendedAction: 'Provide Information' | 'Ask for Missing Information' | 'Route to Billing' | 'Route to Technical Support' | 'Route to Sales' | 'Route to Account Support' | 'Human Review' | 'Recommend Cancellation' | 'Recommend Refund' | 'No Action' | 'Unable to Determine';
  riskLevel: 'Low' | 'Medium' | 'High' | 'Critical';
  requiresHumanApproval: boolean;
  reason: string;
  safetyFlags: SafetyFlag[];
  feedbackMemoryMatched?: {
    memoryId: string;
    matchedSnippet: string;
    suggestedIntent: EmailIntent;
    suggestedAction: RecommendedAction;
    reviewerNote: string;
    similarityScore: number;
  };
  finalOutcome?: 'Completed' | 'Human Approved' | 'Rejected' | 'More Info Needed' | 'Human Review' | 'Processing Failed';
  resolvedAt?: string;
  resolvedBy?: string;
  reviewerNotes?: string;
  createdAt: string;
}
```

### `HumanFeedback`
Operator override record documenting historical intent/action corrections.
```typescript
interface HumanFeedback {
  id: string;
  emailId: string;
  previousIntent: EmailIntent;
  correctedIntent: EmailIntent;
  previousUrgency: EmailUrgency;
  correctedUrgency: EmailUrgency;
  previousAction: RecommendedAction;
  correctedAction: RecommendedAction;
  reviewerNote: string;
  createdAt: string;
}
```

### `FeedbackMemory`
Search-indexed memory knowledge base entry generated from corrections.
```typescript
interface FeedbackMemory {
  id: string;
  exampleEmailSubject: string;
  exampleEmailBody: string;
  keywords: string[];
  correctedIntent: EmailIntent;
  correctedUrgency: EmailUrgency;
  correctedAction: RecommendedAction;
  reviewerNote: string;
  timesApplied: number;
  createdAt: string;
}
```

### `AuditEvent`
Sanitized, immutable audit trail event.
```typescript
interface AuditEvent {
  id: string;
  emailId: string;
  eventType: 'EMAIL_RECEIVED' | 'EMAIL_VALIDATED' | 'AI_ANALYSIS_STARTED' | 'AI_ANALYSIS_COMPLETED' | 'SCHEMA_VALIDATION_FAILED' | 'RETRY_TRIGGERED' | 'PROCESSING_FAILED' | 'DECISION_CREATED' | 'SAFETY_BLOCK' | 'FEEDBACK_MEMORY_MATCHED' | 'HUMAN_REVIEW_REQUIRED' | 'HUMAN_APPROVAL_GRANTED' | 'HUMAN_APPROVAL_REJECTED' | 'HUMAN_INFO_REQUESTED' | 'HUMAN_CORRECTION_SAVED' | 'FINAL_OUTCOME_RECORDED';
  message: string;
  timestamp: string;
  metadata?: Record<string, any>;
}
```
