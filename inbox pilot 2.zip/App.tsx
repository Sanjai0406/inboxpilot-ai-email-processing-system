import React, { useState, useEffect, useCallback } from 'react';
import { Header } from './components/Header';
import { DashboardView } from './components/DashboardView';
import { InboxView } from './components/InboxView';
import { HumanReviewView } from './components/HumanReviewView';
import { FeedbackMemoryView } from './components/FeedbackMemoryView';
import { ProcessingHistoryView } from './components/ProcessingHistoryView';
import { TestCasesView } from './components/TestCasesView';
import { SystemHealthView } from './components/SystemHealthView';
import { DocumentationView } from './components/DocumentationView';
import {
  Email,
  SystemHealthStats,
  SystemConfig,
  AuditEvent,
  FeedbackMemory,
  ProcessingRun,
  TestCaseResult,
  AIAnalysis,
  Decision,
  HumanFeedback,
  EmailIntent,
  EmailUrgency,
  RecommendedAction,
} from './types';

export default function App() {
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [emails, setEmails] = useState<Email[]>([]);
  const [selectedEmailId, setSelectedEmailId] = useState<string | null>(null);
  const [selectedEmailData, setSelectedEmailData] = useState<{
    email: Email;
    analysis?: AIAnalysis;
    decision?: Decision;
    feedback?: HumanFeedback;
    runs?: ProcessingRun[];
    audits?: AuditEvent[];
  } | null>(null);

  const [stats, setStats] = useState<SystemHealthStats | null>(null);
  const [config, setConfig] = useState<SystemConfig | null>(null);
  const [auditLogs, setAuditLogs] = useState<AuditEvent[]>([]);
  const [feedbackMemories, setFeedbackMemories] = useState<FeedbackMemory[]>([]);
  const [processingRuns, setProcessingRuns] = useState<ProcessingRun[]>([]);
  const [testResults, setTestResults] = useState<TestCaseResult[]>([]);

  const [isProcessingEmail, setIsProcessingEmail] = useState<boolean>(false);
  const [isProcessingAll, setIsProcessingAll] = useState<boolean>(false);
  const [isRunningTests, setIsRunningTests] = useState<boolean>(false);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'info' | 'warning' | 'error' } | null>(null);

  const showToast = (message: string, type: 'success' | 'info' | 'warning' | 'error' = 'info') => {
    setToast({ message, type });
    setTimeout(() => setToast(null), 3500);
  };

  const fetchAllData = useCallback(async () => {
    try {
      const [emailsRes, statsRes, configRes, auditsRes, memoriesRes, runsRes] = await Promise.all([
        fetch('/api/emails'),
        fetch('/api/stats'),
        fetch('/api/config'),
        fetch('/api/audit-logs'),
        fetch('/api/feedback-memory'),
        fetch('/api/processing-runs'),
      ]);

      if (emailsRes.ok) {
        const emailList: Email[] = await emailsRes.json();
        setEmails(emailList);
        if (!selectedEmailId && emailList.length > 0) {
          setSelectedEmailId(emailList[0].id);
        }
      }

      if (statsRes.ok) setStats(await statsRes.json());
      if (configRes.ok) setConfig(await configRes.json());
      if (auditsRes.ok) setAuditLogs(await auditsRes.json());
      if (memoriesRes.ok) setFeedbackMemories(await memoriesRes.json());
      if (runsRes.ok) setProcessingRuns(await runsRes.json());
    } catch (err) {
      console.error('Failed to fetch data:', err);
    }
  }, [selectedEmailId]);

  useEffect(() => {
    fetchAllData();
  }, [fetchAllData]);

  // Fetch individual email detail
  const fetchEmailDetail = useCallback(async (id: string) => {
    try {
      const res = await fetch(`/api/emails/${id}`);
      if (res.ok) {
        const data = await res.json();
        setSelectedEmailData(data);
      }
    } catch (err) {
      console.error('Failed to load email details:', err);
    }
  }, []);

  useEffect(() => {
    if (selectedEmailId) {
      fetchEmailDetail(selectedEmailId);
    }
  }, [selectedEmailId, fetchEmailDetail]);

  const handleSelectEmail = (id: string) => {
    setSelectedEmailId(id);
    fetchEmailDetail(id);
  };

  // Process a single email
  const handleProcessEmail = async (
    id: string,
    options?: {
      forceMalformedAI?: boolean;
      forceLLMFailure?: boolean;
      forceLowConfidence?: boolean;
      simulatedRetries?: number;
    }
  ) => {
    setIsProcessingEmail(true);
    try {
      const res = await fetch(`/api/process/${id}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(options || {}),
      });

      if (res.ok) {
        const result = await res.json();
        showToast(
          `Processed email ${id} -> ${result.decision?.recommendedAction || result.email.status}`,
          result.decision?.requiresHumanApproval ? 'warning' : 'success'
        );
        await fetchAllData();
        await fetchEmailDetail(id);
      } else {
        const errData = await res.json();
        showToast(`Processing error: ${errData.error}`, 'error');
      }
    } catch (err: any) {
      showToast(`Pipeline execution failed: ${err.message}`, 'error');
    } finally {
      setIsProcessingEmail(false);
    }
  };

  // Process all pending emails
  const handleProcessAll = async () => {
    setIsProcessingAll(true);
    try {
      const res = await fetch('/api/process-all', { method: 'POST' });
      if (res.ok) {
        const data = await res.json();
        showToast(`Processed ${data.processedCount} emails successfully!`, 'success');
        await fetchAllData();
        if (selectedEmailId) await fetchEmailDetail(selectedEmailId);
      }
    } catch (err: any) {
      showToast(`Process all error: ${err.message}`, 'error');
    } finally {
      setIsProcessingAll(false);
    }
  };

  // Reset / Re-seed store
  const handleSeedData = async () => {
    try {
      const res = await fetch('/api/emails/seed', { method: 'POST' });
      if (res.ok) {
        showToast('Sample test emails reset & re-seeded successfully.', 'info');
        await fetchAllData();
        if (selectedEmailId) await fetchEmailDetail(selectedEmailId);
      }
    } catch (err: any) {
      showToast(`Seed error: ${err.message}`, 'error');
    }
  };

  // Create custom test email
  const handleCreateEmail = async (newEmail: {
    sender: string;
    subject: string;
    body: string;
    categoryTag?: string;
  }) => {
    try {
      const res = await fetch('/api/emails', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newEmail),
      });
      if (res.ok) {
        const created = await res.json();
        showToast(`Test email created (${created.id})`, 'success');
        await fetchAllData();
        setSelectedEmailId(created.id);
      }
    } catch (err: any) {
      showToast(`Create error: ${err.message}`, 'error');
    }
  };

  // Submit human review decision
  const handleSubmitReview = async (params: {
    emailId: string;
    action: 'APPROVE' | 'REJECT' | 'REQUEST_INFO' | 'CORRECT';
    reviewerNotes?: string;
    correctedIntent?: EmailIntent;
    correctedUrgency?: EmailUrgency;
    correctedAction?: RecommendedAction;
  }) => {
    try {
      const res = await fetch('/api/human-review', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(params),
      });

      if (res.ok) {
        showToast(
          params.action === 'CORRECT'
            ? 'Correction saved & FeedbackMemory updated!'
            : `Review resolution saved: ${params.action}`,
          'success'
        );
        await fetchAllData();
        if (selectedEmailId) await fetchEmailDetail(selectedEmailId);
      }
    } catch (err: any) {
      showToast(`Review error: ${err.message}`, 'error');
    }
  };

  // Run automated test suite
  const handleRunTests = async () => {
    setIsRunningTests(true);
    try {
      const res = await fetch('/api/test-cases/run');
      if (res.ok) {
        const data = await res.json();
        setTestResults(data.results || []);
        showToast(`Test Suite Complete: ${data.passed}/${data.total} passed (${data.successRate}%)`, 'success');
        await fetchAllData();
      }
    } catch (err: any) {
      showToast(`Test execution error: ${err.message}`, 'error');
    } finally {
      setIsRunningTests(false);
    }
  };

  // Update system limits
  const handleUpdateConfig = async (newConfig: Partial<SystemConfig>) => {
    try {
      const res = await fetch('/api/config', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newConfig),
      });
      if (res.ok) {
        const data = await res.json();
        setConfig(data.config);
        showToast('System configuration thresholds updated.', 'success');
      }
    } catch (err: any) {
      showToast(`Config error: ${err.message}`, 'error');
    }
  };

  // Quick Demo Triggers for Dashboard
  const handleRunQuickDemo = async (scenario: 'billing' | 'refund' | 'ambiguous') => {
    if (scenario === 'billing') {
      const em = emails.find((e) => e.subject.includes('INV-2026-8849')) || emails[0];
      if (em) {
        setSelectedEmailId(em.id);
        setActiveTab('inbox');
        await handleProcessEmail(em.id);
      }
    } else if (scenario === 'refund') {
      const em = emails.find((e) => e.subject.toLowerCase().includes('refund')) || emails[5];
      if (em) {
        setSelectedEmailId(em.id);
        setActiveTab('inbox');
        await handleProcessEmail(em.id);
      }
    } else if (scenario === 'ambiguous') {
      const em = emails.find((e) => e.subject.toLowerCase().includes('help regarding')) || emails[4];
      if (em) {
        setSelectedEmailId(em.id);
        setActiveTab('inbox');
        await handleProcessEmail(em.id);
      }
    }
  };

  const pendingReviewCount = emails.filter((e) => e.status === 'HUMAN_REVIEW').length;

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col font-sans selection:bg-indigo-500 selection:text-white">
      {/* Global Navigation Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        stats={stats}
        pendingReviewCount={pendingReviewCount}
        onSeedData={handleSeedData}
        onProcessAll={handleProcessAll}
        isProcessingAll={isProcessingAll}
      />

      {/* Main Viewport Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 pt-6 pb-12">
        {activeTab === 'dashboard' && (
          <DashboardView
            stats={stats}
            emails={emails}
            auditLogs={auditLogs}
            onSelectEmail={(id) => {
              handleSelectEmail(id);
              setActiveTab('inbox');
            }}
            onNavigateTab={setActiveTab}
            onRunQuickDemo={handleRunQuickDemo}
          />
        )}

        {activeTab === 'inbox' && (
          <InboxView
            emails={emails}
            selectedEmailId={selectedEmailId}
            selectedEmailData={selectedEmailData}
            onSelectEmail={handleSelectEmail}
            onProcessEmail={handleProcessEmail}
            onCreateEmail={handleCreateEmail}
            onNavigateTab={setActiveTab}
            isProcessing={isProcessingEmail}
          />
        )}

        {activeTab === 'review' && (
          <HumanReviewView
            emails={emails}
            selectedEmailData={selectedEmailData}
            onSelectEmail={handleSelectEmail}
            onSubmitReview={handleSubmitReview}
            onNavigateTab={setActiveTab}
          />
        )}

        {activeTab === 'feedback' && (
          <FeedbackMemoryView
            memories={feedbackMemories}
            onSelectMemory={(id) => {}}
            onNavigateTab={setActiveTab}
          />
        )}

        {activeTab === 'history' && (
          <ProcessingHistoryView
            runs={processingRuns}
            auditLogs={auditLogs}
            emails={emails}
            onSelectEmail={handleSelectEmail}
            onNavigateTab={setActiveTab}
          />
        )}

        {activeTab === 'tests' && (
          <TestCasesView
            testResults={testResults}
            onRunTests={handleRunTests}
            isRunningTests={isRunningTests}
          />
        )}

        {activeTab === 'health' && (
          <SystemHealthView
            stats={stats}
            config={config}
            auditLogs={auditLogs}
            onUpdateConfig={handleUpdateConfig}
            onRefreshStats={fetchAllData}
          />
        )}

        {activeTab === 'docs' && <DocumentationView />}
      </main>

      {/* Floating Toast Notification */}
      {toast && (
        <div className="fixed bottom-5 right-5 z-50 animate-bounce">
          <div
            className={`px-4 py-2.5 rounded-xl shadow-2xl text-xs font-semibold flex items-center space-x-2 border ${
              toast.type === 'success'
                ? 'bg-emerald-600 text-white border-emerald-500'
                : toast.type === 'warning'
                ? 'bg-amber-600 text-white border-amber-500'
                : toast.type === 'error'
                ? 'bg-rose-600 text-white border-rose-500'
                : 'bg-slate-800 text-slate-100 border-slate-700'
            }`}
          >
            <span>{toast.message}</span>
          </div>
        </div>
      )}
    </div>
  );
}
