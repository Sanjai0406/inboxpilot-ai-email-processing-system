# Architectural & Engineering Design Decisions

## 1. Separation of LLM Understanding from Decision Logic
* **Decision:** The LLM is strictly constrained to **semantic entity extraction and classification** (`intent`, `importantDetails`, `urgency`, `missingInformation`, `confidence`). It is **never** granted permission to choose final actions, dispatch emails, or call external APIs.
* **Rationale:** LLMs are probabilistic text predictors prone to hallucination, sycophancy, or prompt injection. Purely deterministic code (TypeScript switch cases and guardrail validators) guarantees verifiable business policy compliance.

---

## 2. Mandatory Human Approval for High-Impact & Financial Actions
* **Decision:** Any request involving refunds, payments, cancellations, GDPR Article 17 data erasures, or security changes is flagged as `High` or `Critical` risk and requires explicit human review.
* **Rationale:** Financial and legal transactions carry irreversible real-world liabilities. Automating payment reversals or data deletion without human verification introduces catastrophic operational vulnerabilities.

---

## 3. Missing Information Blocks Automated Progression
* **Decision:** When an email lacks necessary parameters (such as an invoice number, account identifier, or error log), the system outputs `Ask for Missing Information` rather than guessing or progressing.
* **Rationale:** Guessing customer intent or routing to a department without relevant context wastes support agent hours and creates customer friction.

---

## 4. Confidence Threshold Enforcement ($< 0.70 \rightarrow \text{Human Review}$)
* **Decision:** If the LLM confidence score falls below $0.70$ or if the intent is marked `Unknown`, automated department routing is inhibited.
* **Rationale:** A $30\%+$ uncertainty margin represents high ambiguity. Sending ambiguous queries directly to specialized departments leads to ticket ping-pong.

---

## 5. Lightweight Feedback Memory vs. Model Fine-Tuning
* **Decision:** We implement an auditable **Feedback Memory** repository of human corrections using keyword and similarity matching rather than claiming dynamic model retraining.
* **Rationale:** In enterprise systems, online fine-tuning on single user corrections is both technically impractical, cost-prohibitive, and vulnerable to catastrophic forgetting or poisoning. A memory layer provides transparent, controllable, immediate guidance while ensuring safety rules remain permanently enforced.

---

## 6. Max Retries Limit ($\text{MAX\_RETRIES} = 3$) with Escalation
* **Decision:** Retry transient API failures up to 3 times with exponential backoff. If exhausted, escalate directly to the Human Review queue rather than failing silently.
* **Rationale:** Preserves the incoming customer email without loss while alerting support personnel that automated processing could not be completed.

---

## 7. Simulated External Actions
* **Decision:** All external outcomes (e.g. issuing a simulated refund or applying a test cancellation) are clearly labeled as simulated with no fake external API claims.
* **Rationale:** Promotes honest engineering practices and prevents misleading operators into believing external banking or CRM systems were modified.

---

## 8. Server-Side Secret Management
* **Decision:** `GEMINI_API_KEY` and backend logic reside strictly in the Express server environment.
* **Rationale:** Prevents exposure of proprietary API keys to client-side browser bundles and DevTools.
