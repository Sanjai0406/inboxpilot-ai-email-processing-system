export type EmailStatus = 'RECEIVED' | 'PROCESSING' | 'COMPLETED' | 'HUMAN_REVIEW' | 'FAILED';

export type EmailIntent =
  | 'Billing'
  | 'Technical Support'
  | 'Sales'
  | 'Account Support'
  | 'General Support'
  | 'Complaint'
  | 'Cancellation'
  | 'Refund'
  | 'Other'
  | 'Unknown';

export type EmailUrgency = 'Low' | 'Medium' | 'High' | 'Critical' | 'Unknown';

export type RiskLevel = 'Low' | 'Medium' | 'High' | 'Critical';

export type RecommendedAction =
  | 'Provide Information'
  | 'Ask for Missing Information'
  | 'Route to Billing'
  | 'Route to Technical Support'
  | 'Route to Sales'
  | 'Route to Account Support'
  | 'Human Review'
  | 'Recommend Cancellation'
  | 'Recommend Refund'
  | 'No Action'
  | 'Unable to Determine';

export type FinalOutcome =
  | 'Completed'
  | 'Human Approved'
  | 'Rejected'
  | 'More Info Needed'
  | 'Human Review'
  | 'Processing Failed';

export interface Email {
  id: string;
  sender: string;
  subject: string;
  body: string;
  receivedAt: string;
  status: EmailStatus;
  categoryTag?: string;
  simulatedScenario?: string;
}

export interface ProcessingRun {
  id: string;
  emailId: string;
  status: 'PENDING' | 'RUNNING' | 'SUCCESS' | 'FAILED' | 'ESCALATED';
  startedAt: string;
  completedAt?: string;
  retryCount: number;
  error?: string;
  processingTimeMs: number;
  attempts: Array<{
    attemptNumber: number;
    timestamp: string;
    stage: string;
    success: boolean;
    error?: string;
    durationMs: number;
  }>;
}

export interface AIAnalysis {
  id: string;
  emailId: string;
  intent: EmailIntent;
  importantDetails: string[];
  urgency: EmailUrgency;
  missingInformation: string[];
  confidence: number;
  reasoningSummary: string;
  rawJson?: string;
  validationPassed: boolean;
  validationErrors?: string[];
  createdAt: string;
}

export interface SafetyFlag {
  type:
    | 'MISSING_INFO'
    | 'LOW_CONFIDENCE'
    | 'FINANCIAL_ACTION'
    | 'REFUND_REQUEST'
    | 'SECURITY_OR_OWNERSHIP'
    | 'DELETION_OR_IRREVERSIBLE'
    | 'HIGH_IMPACT_COMPLAINT'
    | 'AI_MALFUNCTION'
    | 'UNKNOWN_INTENT';
  severity: RiskLevel;
  description: string;
  triggeredRule: string;
}

export interface Decision {
  id: string;
  emailId: string;
  recommendedAction: RecommendedAction;
  riskLevel: RiskLevel;
  requiresHumanApproval: boolean;
  reason: string;
  safetyFlags: SafetyFlag[];
  feedbackMemoryMatched?: {
    memoryId: string;
    matchedSnippet: string;
    suggestedIntent: EmailIntent;
    suggestedAction: RecommendedAction;
    reviewerNote: string;
    similarityScore: number;
  };
  finalOutcome?: FinalOutcome;
  resolvedAt?: string;
  resolvedBy?: string;
  reviewerNotes?: string;
  createdAt: string;
}

export interface HumanFeedback {
  id: string;
  emailId: string;
  previousIntent: EmailIntent;
  correctedIntent: EmailIntent;
  previousUrgency: EmailUrgency;
  correctedUrgency: EmailUrgency;
  previousAction: RecommendedAction;
  correctedAction: RecommendedAction;
  reviewerNote: string;
  createdAt: string;
}

export interface FeedbackMemory {
  id: string;
  exampleEmailSubject: string;
  exampleEmailBody: string;
  keywords: string[];
  correctedIntent: EmailIntent;
  correctedUrgency: EmailUrgency;
  correctedAction: RecommendedAction;
  reviewerNote: string;
  timesApplied: number;
  createdAt: string;
}

export type AuditEventType =
  | 'EMAIL_RECEIVED'
  | 'EMAIL_VALIDATED'
  | 'AI_ANALYSIS_STARTED'
  | 'AI_ANALYSIS_COMPLETED'
  | 'SCHEMA_VALIDATION_FAILED'
  | 'RETRY_TRIGGERED'
  | 'PROCESSING_FAILED'
  | 'DECISION_CREATED'
  | 'SAFETY_BLOCK'
  | 'FEEDBACK_MEMORY_MATCHED'
  | 'HUMAN_REVIEW_REQUIRED'
  | 'HUMAN_APPROVAL_GRANTED'
  | 'HUMAN_APPROVAL_REJECTED'
  | 'HUMAN_INFO_REQUESTED'
  | 'HUMAN_CORRECTION_SAVED'
  | 'FINAL_OUTCOME_RECORDED';

export interface AuditEvent {
  id: string;
  emailId: string;
  eventType: AuditEventType;
  message: string;
  timestamp: string;
  metadata?: Record<string, any>;
}

export interface SystemConfig {
  maxRetries: number;
  maxEmailLength: number;
  maxOutputTokens: number;
  maxProcessingTimeMs: number;
  minConfidenceThreshold: number;
  enableRealGemini: boolean;
}

export interface SystemHealthStats {
  llmStatus: 'ONLINE' | 'DEGRADED' | 'SIMULATED';
  apiKeyConfigured: boolean;
  totalEmails: number;
  processedCount: number;
  autoCompletedCount: number;
  humanReviewCount: number;
  safetyBlockCount: number;
  retryCount: number;
  failedCount: number;
  averageProcessingTimeMs: number;
  successRate: number;
  feedbackMemoryCount: number;
  auditEventsCount: number;
}

export interface TestCaseResult {
  id: string;
  name: string;
  category: string;
  description: string;
  inputEmail: {
    sender: string;
    subject: string;
    body: string;
  };
  expected: {
    intent: EmailIntent | string;
    riskLevel?: RiskLevel;
    requiresHumanReview: boolean;
    expectedActionPattern?: string;
    expectedSafetyFlag?: string;
  };
  actual?: {
    intent?: EmailIntent;
    confidence?: number;
    riskLevel?: RiskLevel;
    requiresHumanReview?: boolean;
    recommendedAction?: RecommendedAction;
    safetyFlags?: string[];
    error?: string;
  };
  passed: boolean;
  executionTimeMs: number;
  details: string;
}
