# System Limitations & Production Readiness Road Map

## 1. Current System Limitations

1. **Synthetic Sample Data:** The application utilizes realistic synthetic emails designed for assessment evaluation. In production, this would ingest raw MIME multipart streams from IMAP/SMTP or Microsoft Graph / Gmail APIs.
2. **LLM Output Stochasticity:** While strict JSON schema validation and deterministic fallback logic are enforced, LLM temperature and upstream token variations can introduce slight reasoning nuances.
3. **Feedback Memory vs. Continuous Training:** The system utilizes indexed keyword/similarity matching over historical reviewer corrections (`FeedbackMemory`). It does **not** fine-tune or retrain model weights online.
4. **Simulated External Actions:** Financial refunds, contract cancellations, and database erasures are safely simulated within the application state and do not invoke actual third-party payment gateways (e.g. Stripe) or CRM write operations.
5. **Session-Level In-Memory Store:** The current assessment prototype uses an in-memory data repository.

---

## 2. Production Deployment Enhancements

To deploy InboxPilot to enterprise production scale, the following enhancements would be added:

- **Database Persistence:** Migrate from in-memory to PostgreSQL / Google Cloud SQL with ACID transactions and schema migrations.
- **Enterprise IAM & Role-Based Access (RBAC):** Integrate SSO / OIDC (Okta, Azure AD) with fine-grained reviewer roles (Tier 1 Support, Billing Manager, Compliance Officer).
- **Vector Search for Feedback Memory:** Upgrade keyword-based similarity matching to dense vector embeddings (e.g. using `gemini-embedding-2-preview` with pgvector or Vertex AI Vector Search).
- **Rate Limiting & Distributed Queues:** Implement BullMQ / Redis or Google Cloud Pub/Sub with dead-letter queues to handle bursty email traffic.
- **Data Retention & Encryption:** Implement column-level encryption for PII (Personally Identifiable Information) and automated 30-day log purging compliant with GDPR/HIPAA standards.
- **Live Third-Party Connectors:** Add authenticated webhooks to Jira Service Desk, Zendesk, Salesforce Service Cloud, and Stripe API with dual-custody authorization for high-risk payouts.
