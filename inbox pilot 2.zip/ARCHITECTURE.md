# System Architecture & Flow Specifications

## 1. System Pipeline Architecture

```
                       ┌──────────────────────┐
                       │     Incoming Email   │
                       │ Sender / Subject /   │
                       │ Body / Timestamp     │
                       └──────────┬───────────┘
                                  │
                                  ▼
                       ┌──────────────────────┐
                       │   Email Processor    │
                       │ Validate + Normalize │
                       │ Length / Input Check │
                       └──────────┬───────────┘
                                  │
                                  ▼
                       ┌──────────────────────┐
                       │    LLM AI Analysis   │
                       │    Gemini 3.8 Flash  │
                       │                      │
                       │ • Intent             │
                       │ • Important Details  │
                       │ • Urgency            │
                       │ • Missing Info       │
                       │ • Confidence         │
                       │ • Reasoning          │
                       └──────────┬───────────┘
                                  │
                                  ▼
                       ┌──────────────────────┐
                       │ Structured Output    │
                       │     Validation       │
                       │                      │
                       │ Valid JSON?          │
                       │ Required fields?     │
                       │ Confidence valid?    │
                       └──────────┬───────────┘
                                  │
                       ┌──────────┴──────────┐
                       │                     │
                     VALID                INVALID
                       │                     │
                       ▼                     ▼
            ┌──────────────────┐   ┌──────────────────┐
            │ Decision Engine  │   │ Retry Handler    │
            │                  │   │                  │
            │ Deterministic    │   │ Retry ≤ 3        │
            │ Business Rules   │   │ Backoff          │
            └────────┬─────────┘   └────────┬─────────┘
                     │                      │
                     │               Max retries?
                     │                      │
                     │                      ▼
                     │              ┌────────────────┐
                     │              │ Human Review   │
                     │              └────────────────┘
                     ▼
            ┌──────────────────────┐
            │   Safety Guardrails  │
            │                      │
            │ • Missing info       │
            │ • Low confidence     │
            │ • Financial action   │
            │ • Refund             │
            │ • Security change    │
            │ • Deletion           │
            │ • Irreversible act.  │
            └──────────┬───────────┘
                       │
             ┌─────────┴─────────┐
             │                   │
           SAFE              HIGH RISK
             │                   │
             ▼                   ▼
     ┌──────────────┐    ┌──────────────────┐
     │ Recommended  │    │  Human Review    │
     │    Action    │    │                  │
     │              │    │ Approve          │
     │ Route / Info │    │ Reject           │
     │ / Ask Info   │    │ Request Info     │
     └──────┬───────┘    └────────┬─────────┘
            │                     │
            └──────────┬──────────┘
                       ▼
              ┌──────────────────┐
              │   Final Outcome  │
              │                  │
              │ Completed        │
              │ Human Approved   │
              │ Rejected         │
              │ More Info Needed │
              │ Human Review     │
              └────────┬─────────┘
                       │
                       ▼
              ┌──────────────────┐
              │   Audit Logger   │
              │                  │
              │ Every processing │
              │ event recorded   │
              └──────────────────┘
```

---

## 2. Human Feedback & Feedback Memory Loop

```
     ┌────────────────────────────────────────────┐
     │             FEEDBACK LOOP                  │
     │                                            │
     │ Human Correction                           │
     │        │                                   │
     │        ▼                                   │
     │ HumanFeedback                              │
     │        │                                   │
     │        ▼                                   │
     │ FeedbackMemory                             │
     │        │                                   │
     │        ▼                                   │
     │ Similar Future Email                       │
     │        │                                   │
     │        ▼                                   │
     │ Feedback-Informed Suggestion               │
     │                                            │
     │ Safety rules ALWAYS remain active          │
     └────────────────────────────────────────────┘
```

---

## 3. Layer Separation & Responsibilities

| Layer | Responsibility | Isolation Guarantee |
| :--- | :--- | :--- |
| **Email Processor** | Normalizes text, enforces max length boundaries (4,000 chars), validates non-empty payloads. | Rejects malformed input prior to LLM invocation. |
| **LLM Analysis (Gemini)** | Semantic entity extraction, classification of Intent & Urgency, identifies missing fields, outputs reasoning. | Operates in sandboxed read-only mode; cannot invoke tools or execute mutations. |
| **Structured Output Validator** | Asserts JSON syntax, field existence, enum validity, and confidence range $[0.0, 1.0]$. | Traps malformed AI output and feeds to Retry Handler. |
| **Retry & Backoff Handler** | Manages transient errors with exponential delay (up to 3 retries). | Automatically escalates to Human Review upon exhaustion. |
| **Decision Engine** | Evaluates deterministic business rules and links Department Routing. | Completely separated from LLM generation logic. |
| **Safety Guardrails** | Scans for financial, refund, GDPR deletion, account takeover, or low-confidence triggers. | Urgency cannot override safety blocks; guarantees human-in-the-loop. |
| **Feedback Memory** | Index of historical operator corrections with keyword similarity matching. | Informs future suggestions; strictly prohibited from bypassing safety. |
| **Audit Logger** | Records immutable timestamped events with sanitized metadata. | Secrets and API keys are scrubbed before persistence. |
